import { Injectable } from '@angular/core';
import { Observable, of } from 'rxjs';
import { faWpforms } from '@fortawesome/free-brands-svg-icons';

import {
  faTable,
  faEdit,
  faChartLine,
  faCalendarAlt,
  faPuzzlePiece,
  faTh,
  faReceipt,
  faLayerGroup,
  faInbox,
  faCircle,
  faUserShield,
  faCog,
  faFileAlt,
  faKey,
  faUserPlus,
  faUserSecret,
  faUsers,
  faUser,
  faMagic,
  faHome,
  faStore,
  faSuitcase,
  faCheckSquare,
  faLifeRing
} from '@fortawesome/free-solid-svg-icons';

import { NavigationOptions } from '../models/navigation';
import { parseInt } from 'lodash';

@Injectable({
  providedIn: 'root',
})
export class NavigationService {
  AllItems: any[] = [];
  constructor() { }

  getNavigationItems(): Observable<NavigationOptions[]> {
    debugger;
    let filtered = new Array();
    let result = new Array();
    let MenuList = JSON.parse(localStorage.getItem("credentials") || sessionStorage.getItem("credentials"));

    let menu = new Array<NavigationOptions>()
    menu = this.getAllNavigation();
    menu.map((item: any) => {
      filtered = [];
      item.items.map((i: any) => {
        MenuList.menu.map((element: string) => {
          if (i.level.toString() == element) {
            filtered.push(i);
          }
        });
      });
      item.items = filtered;
      result.push(item);
    });
    for (let index = 0; index < result.length; index++) {
      if (result[index].items.length == 0) {
        result.splice(index, 1);
      }
    }

    return of([
      {
        title: 'Main',
        icon: { name: faLayerGroup },
        items: [
          {
            icon: { name: faHome },
            title: 'Home Page',
            link: '/starter',
            level: 1
          },


        ],
      },
      {
        title: 'Management',
        icon: { name: faTh },
        items: result,
      },


    ]);
  }
  getAllNavigation(): NavigationOptions[] {
    debugger
    this.AllItems = new Array<NavigationOptions>(
      {
        title: 'Admin',
        icon: { name: faUserShield },
        items: [
          { link: '/Admin/List', title: 'List', icon: { letter: 'L' }, level: 2 },
          { link: '/Admin/New', title: 'New', icon: { letter: 'C' }, level: 3 },
        ],
      },
      {
        title: 'User',
        icon: { name: faUser },
        items: [
          { link: '/User/List', title: 'List', icon: { letter: 'L' }, level: 8 },
          { link: '/User/New', title: 'New', icon: { letter: 'C' }, level: 9 },
        ],
      },
      {
        title: 'ServiceProvider',
        icon: { name: faUser },
        items: [
          { link: '/ServiceProvider/List', title: 'List', icon: { letter: 'L' }, level: 10 },
          { link: '/ServiceProvider/New', title: 'New', icon: { letter: 'C' }, level: 11 },
        ],
      }
    )

    return this.AllItems;
  }
}
